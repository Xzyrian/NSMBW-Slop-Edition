/* rt_det.c - deterministic mode: what online play needs from the emulation (docs/ONLINE.md).
 *
 * With g_det on (RT_DETERMINISTIC=1, or an online session) the emulated hardware runs on a
 * virtual clock (rt_core.c) and everything the game can see from outside changes only at video
 * field boundaries (det_field): the controllers' buttons are latched there, the real-time clock
 * is a fixed date. Two PCs that start the same way and get the same buttons per field then run
 * the same game, frame for frame - the base of lockstep and rollback netplay.
 *
 * Testing: RT_DET_HASH=file writes, per field, a hash of the game's memory (MEM1 + MEM2); two
 * runs with the same inputs must give the same file (tools: diff / cmp). */
#include "rt.h"
#define XXH_INLINE_ALL
#include "xxhash.h"
#if !defined(_WIN32)
#include <sys/mman.h>
#include <signal.h>
#include <ucontext.h>
#include <execinfo.h>
#include <unistd.h>
/* RT_DET_WATCHW=word (with RT_DET_WATCH_AT): every write to that one word from that field on, with a
   backtrace and the registers of the last poll's context (the running guest thread's ctx), by
   write-protecting its page and single-stepping each write to that page (x86-64 trap flag) */
static void *wt_page; static uint32_t wt_word;
static void wt_trap(int sig, siginfo_t *si, void *uc) { (void)sig; (void)si;
    mprotect(wt_page, 0x1000, PROT_READ); ((ucontext_t *)uc)->uc_mcontext.gregs[17 /* REG_EFL */] &= ~0x100; }
static void watch_hit(int sig, siginfo_t *si, void *uc) {
    if (getenv("RT_DET_WATCHW")) {
        uint32_t ga = (uint32_t)((uint8_t *)si->si_addr - g_base) | 0x80000000u;
        if ((ga & ~3u) == wt_word) { void *bt[24]; int n = backtrace(bt, 24); extern uint64_t g_vi_fields;
            fprintf(stderr, "[det] WORD write %08X field %llu val-before %08X\n", ga, (unsigned long long)g_vi_fields, R32(wt_word)); backtrace_symbols_fd(bt, n, 2);
            extern ppc_context *volatile g_poll_ctx; ppc_context *c = g_poll_ctx;
            if (c) { for (int i = 0; i < 32; i++) fprintf(stderr, "r%d=%08X%s", i, c->r[i], i % 8 == 7 ? "\n" : " ");
                     for (int i = 0; i < 32; i++) fprintf(stderr, "f%d=%016llX/%g%s", i, (unsigned long long)c->f[i].u, c->ps1[i], i % 4 == 3 ? "\n" : " ");
                     if (getenv("RT_DET_WATCHSTK")) for (uint32_t o = 0; o < 0x700; o += 4) fprintf(stderr, "stk %08X %08X\n", c->r[1] - 0x400 + o, R32(c->r[1] - 0x400 + o)); } }
        mprotect(wt_page, 0x1000, PROT_READ | PROT_WRITE);
        ((ucontext_t *)uc)->uc_mcontext.gregs[17 /* REG_EFL */] |= 0x100; return;
    }
    (void)sig; (void)uc;
    void *bt[24]; int n = backtrace(bt, 24);
    extern ppc_context *volatile g_poll_ctx;
    fprintf(stderr, "[det] write to watched page at %p (guest %08X; last poll: r1 %08X lr %08X, OS thread %08X, current context %08X)\n", si->si_addr, (uint32_t)((uint8_t *)si->si_addr - g_base) | 0x80000000u,
            g_poll_ctx ? g_poll_ctx->r[1] : 0, g_poll_ctx ? g_poll_ctx->lr : 0, R32(0x800000E4u), R32(0x800000D4u));
    backtrace_symbols_fd(bt, n, 2);
    mprotect((void *)((uintptr_t)si->si_addr & ~0xFFFull), 0x1000, PROT_READ | PROT_WRITE);
}
#endif

static uint32_t kb_latched RT_STATE;              /* (the game reads it until the next field: part of a state) */
static FILE *hash_out;
static int hash_init;
extern uint64_t g_vi_fields;

/* 4 KB pages of MEM1 (24 MB) and MEM2 (64 MB) that EFB copies write: not the game's state (they
   differ with the renderer and its settings), so not hashed */
#define PG_MEM1 (32u << 8)                 /* (MEM1 24 MB + the PC mod loaded above it at 0x81800000) */
#define PG_ALL  (PG_MEM1 + (64u << 8))
static uint8_t skip_pg[PG_ALL] RT_STATE;          /* (where the game has EFB copies go: same everywhere, part of a state) */
void det_renderer_writes(uint32_t phys, uint32_t bytes) {
    phys &= 0x1FFFFFFF;
    for (uint32_t a = phys & ~0xFFFu; a < phys + bytes; a += 0x1000) {
        uint32_t pg = a < (32u << 20) ? a >> 12 : (a >= 0x10000000u && a < 0x14000000u) ? PG_MEM1 + ((a - 0x10000000u) >> 12) : 0xFFFFFFFFu;
        if (pg < PG_ALL) skip_pg[pg] = 1;
    }
}
/* RT_DET_HASH_LIVE=1 (testing the decompiled game code, docs/NATIVE_ROADMAP.md track B): the hash
   leaves out what a native function can't help changing without the game seeing it - every guest
   thread's stack (a recompiled function's frame, dead after it returns) and saved register context
   (volatile registers saved at a thread switch). Threads: the OS's active thread queue. */
static int live_ranges(uint32_t *lo, uint32_t *hi, int max) {
    int n = 0;
    uint32_t t = R32(0x800000DCu);                                 /* __OSActiveThreadQueue.head */
    for (int guard = 0; t >= 0x80000000u && t < 0x94000000u && guard < 64 && n + 2 <= max; guard++) {
        uint32_t base = R32(t + 0x304), end = R32(t + 0x308);      /* OSThread: stackBase (top), stackEnd */
        lo[n] = t; hi[n] = t + 0x2C8; n++;                          /* its OSContext */
        if (end >= 0x80000000u && base > end && base - end < (16u << 20)) { lo[n] = end; hi[n] = base; n++; }
        t = R32(t + 0x2FC);                                         /* linkActive.next */
    }
    /* and the SDK's private stacks (OSSwitchFiber / OSSwitchFiberEx): the Wii remote libraries run
       their alarm handlers on these, and a handler's frames keep the interrupted code's registers */
    static const uint32_t fiber[] = { 0x8039E340u, 0x803A4080u, 0x803CDE40u, 0x803CEE40u, 0x803D0620u };
    for (int i = 0; i < (int)(sizeof fiber / sizeof *fiber) && n < max; i++) { lo[n] = fiber[i]; hi[n] = fiber[i] + 0x1000; n++; }
    return n;
}
uint64_t det_state_hash(void) {
    static XXH3_state_t st; XXH3_64bits_reset(&st);
    static int live = -1; if (live < 0) live = getenv("RT_DET_HASH_LIVE") != NULL;
    uint32_t lo[140], hi[140]; int nr = live ? live_ranges(lo, hi, 138) : 0;
    static uint8_t pagebuf[0x1000];
    for (uint32_t pg = 0; pg < PG_ALL; pg++) {
        if (skip_pg[pg]) continue;
        uint32_t a = pg < PG_MEM1 ? 0x80000000u + (pg << 12) : 0x90000000u + ((pg - PG_MEM1) << 12);
        const uint8_t *src = G(a);
        for (int i = 0; i < nr; i++) if (lo[i] < a + 0x1000 && hi[i] > a) {
            if (src != pagebuf) { memcpy(pagebuf, src, 0x1000); src = pagebuf; }
            uint32_t s0 = lo[i] > a ? lo[i] - a : 0, s1 = hi[i] < a + 0x1000 ? hi[i] - a : 0x1000;
            memset(pagebuf + s0, 0, s1 - s0);
        }
        XXH3_64bits_update(&st, src, 0x1000);
    }
    return XXH3_64bits_digest(&st);
}
void session_field(void);
/* testing save states (rt_state.c), RT_DETERMINISTIC=1 runs:
   RT_SNAP_TEST="S,L"    take a state at field S, load it back at field L (the fields after S
                         must then hash the same both times: RT_DET_HASH);
   RT_SNAP_SAVE="F:file" write a state at field F to a file; RT_SNAP_LOAD="F:file" load one at
                         field F (in another copy: it must then go on exactly like the first) */
static void snap_tests(void) {
    static int init; static long t_s = -1, t_l = -1, sv_f = -1, ld_f = -1; static char sv_p[512], ld_p[512];
    static rt_snap *snap; static int resumed;
    if (!init) {
        init = 1; const char *e;
        if ((e = getenv("RT_SNAP_TEST"))) sscanf(e, "%ld,%ld", &t_s, &t_l);
        if ((e = getenv("RT_SNAP_SAVE"))) sscanf(e, "%ld:%511s", &sv_f, sv_p);
        if ((e = getenv("RT_SNAP_LOAD"))) sscanf(e, "%ld:%511s", &ld_f, ld_p);
        snap = rt_snap_new();
    }
    long F = (long)g_vi_fields;
    if (F == t_s && !resumed) {
        uint64_t t = rt_now_ns(); int r = rt_snap_take(snap);
        if (r == 1) { resumed = 1; rt_log("state", "test: resumed at field %ld", F); void rt_snap_compare(rt_snap *); rt_snap_compare(snap); }
        else { size_t n; rt_snap_data(snap, &n); rt_log("state", "test: state at field %ld (%.1f MB, %.1f ms)%s", F, n / 1048576.0, (rt_now_ns() - t) / 1e6, r < 0 ? " FAILED" : ""); }
    }
    if (F == t_l && !resumed) { rt_log("state", "test: loading the state of field %ld", t_s); rt_snap_load(snap); }
    if (F == sv_f) {
        int r = rt_snap_take(snap);
        if (r == 0) { size_t n; const uint8_t *d = rt_snap_data(snap, &n); FILE *f = fopen(sv_p, "wb"); if (f) { fwrite(d, 1, n, f); fclose(f); } rt_log("state", "test: wrote the state of field %ld (%.1f MB)", F, n / 1048576.0); }
        else if (r == 1) rt_log("state", "test: resumed (field %ld)", F);
    }
    if (F == ld_f && !resumed) {
        FILE *f = fopen(ld_p, "rb"); if (!f) { rt_log("state", "test: no %s", ld_p); return; }
        fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
        uint8_t *d = malloc(n); if (fread(d, 1, n, f) != (size_t)n) n = 0; fclose(f);
        if (!rt_snap_set(snap, d, (size_t)n)) { rt_log("state", "test: %s isn't a state of this build", ld_p); free(d); return; }
        free(d); resumed = 1;
        rt_log("state", "test: loading %s at field %ld", ld_p, F);
        rt_snap_load(snap);
    }
}
/* Play recordings (tools/record_play.bat, tools/ab_inputs/README.md): RT_REC=file writes the
   keyboard's buttons as latched for each field - a "field mask" line (hex) wherever they change -
   and RT_REPLAY=file plays such a file back in place of the keyboard. In deterministic mode the
   game only sees the buttons per field, so a recording made by hand on one PC replays the same
   game anywhere (with the same start: nand, settings.ini, wiimotes.ini, profiles.json). Not while
   running fields again (rollback) - and a save state loaded while recording breaks it. */
static void rec_field(void) {
    static int init; static FILE *rec, *rep; static uint32_t last = 0xFFFFFFFFu, cur, nm;
    static unsigned long long nf = ~0ull;
    if (!init) {
        init = 1;
        const char *p = getenv("RT_REC"); if (p && *p) { rec = fopen(p, "w"); rt_log("det", "recording the keyboard to %s%s", p, rec ? "" : " - can't write it"); }
        p = getenv("RT_REPLAY"); if (p && *p) { rep = fopen(p, "r"); rt_log("det", "replaying %s%s", p, rep ? "" : " - can't read it"); }
        if (rep && fscanf(rep, "%llu %x", &nf, &nm) != 2) nf = ~0ull;
    }
    if (g_resim) return;
    if (rep) {
        while (nf <= (unsigned long long)g_vi_fields) { cur = nm; if (fscanf(rep, "%llu %x", &nf, &nm) != 2) nf = ~0ull; }
        kb_latched |= cur;
    }
    if (rec && kb_latched != last) { fprintf(rec, "%llu %x\n", (unsigned long long)g_vi_fields, kb_latched); fflush(rec); last = kb_latched; }
}
void det_field(void) {
    {   static int f = -1; if (f < 0) { f = getenv("RT_DET_UNPACED") != NULL; } if (f) { extern int g_det_fast; g_det_fast = 1; } }   /* testing: as fast as it goes */
    kb_latched = plat_buttons();
    rec_field();
    snap_tests();
    {   /* testing: RT_RB_TEST="start:every:depth" - rollback states from field `start`, and every
           `every` fields go back `depth` and run them again (the hashes must not change: RT_DET_HASH) */
        static long st = -2, every, depth; static uint32_t resim_to, rolled; static uint64_t nrb, tns;
        if (st == -2) { const char *e = getenv("RT_RB_TEST"); st = -1; if (e) sscanf(e, "%ld:%ld:%ld", &st, &every, &depth); }
        if (st >= 0 && !session_on()) {
            uint32_t F = (uint32_t)g_vi_fields;
            if ((long)F == st && !rb_active()) rb_start();
            if (rb_active()) {
                static uint64_t t0;
                rb_save(F, 1);
                int was = g_resim;
                g_resim = (int32_t)(resim_to - F) > 0;
                if (was && !g_resim) { tns += rt_now_ns() - t0; if (++nrb % 50 == 0) { double sm; uint64_t sv; rb_stats(&sm, &sv, NULL); rt_log("state", "test: %llu rollbacks of %ld fields, %.2f ms each to run them again; keeping a state %.2f ms/field", (unsigned long long)nrb, depth, tns / 1e6 / 50, sm); tns = 0; } }
                if (!g_resim && (long)F > st + depth && ((long)F - st) % every == 0 && F != rolled) { rolled = F; resim_to = F; t0 = rt_now_ns(); rb_rollback(F - (uint32_t)depth); }
            }
        }
    }
    {   static int dp = -1; if (dp < 0) dp = getenv("RT_DIRTY_PROBE") != NULL; if (dp) { void rt_dirty_probe(void); rt_dirty_probe(); } }
    if (net_snap_pending()) net_snap_point();              /* (the online game starts here: rt_net.c) */
    if (session_on()) session_field();                      /* (online: everyone's buttons for this field - rt_net.c) */
#if !defined(_WIN32)
    {   static long at = -2; if (at == -2) { const char *e = getenv("RT_DET_WATCH_AT"); at = e ? atol(e) : -1; }   /* testing: who writes there */
        if (at >= 0 && (long)g_vi_fields == at) {
            uint32_t a = (uint32_t)strtoul(getenv("RT_DET_WATCH"), NULL, 16);
            struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_sigaction = watch_hit; sa.sa_flags = SA_SIGINFO; sigaction(SIGSEGV, &sa, NULL);
            if (getenv("RT_DET_WATCHW")) { wt_word = (uint32_t)strtoul(getenv("RT_DET_WATCHW"), NULL, 16); wt_page = (void *)((uintptr_t)G(wt_word) & ~0xFFFull);
                struct sigaction st; memset(&st, 0, sizeof st); st.sa_sigaction = wt_trap; st.sa_flags = SA_SIGINFO; sigaction(SIGTRAP, &st, NULL);
                mprotect(wt_page, 0x1000, PROT_READ); } else
            mprotect(G(a), 0x10000, PROT_READ);
        } }
#endif
    {   static int jit = -1; if (jit < 0) jit = getenv("RT_DET_JITTER") != NULL;   /* testing: the PC's timing must not matter */
        if (jit) { static uint32_t r = 12345; r = r * 1103515245u + 12345u; plat_idle_wait((uint64_t)((r >> 16) % 12) * 1000000ull); } }
    if (!hash_init) { hash_init = 1; const char *p = getenv("RT_DET_HASH"); if (p) hash_out = fopen(p, "w"); }
    {   static long at = -2; if (at == -2) { const char *e = getenv("RT_DET_DUMP_AT"); at = e ? atol(e) : -1; }   /* testing: per-page hashes */
        if (at >= 0 && (long)g_vi_fields == at && getenv("RT_DET_HASH")) {
            static int pass; pass++;                        /* (a state test passes here twice: .pages, .pages2) */
            char p[1200]; snprintf(p, sizeof p, pass > 1 ? "%s.pages%d" : "%s.pages", getenv("RT_DET_HASH"), pass); FILE *f = fopen(p, "w");
            if (f) { for (uint32_t pg = 0; pg < PG_ALL; pg++) { uint32_t a = pg < PG_MEM1 ? 0x80000000u + (pg << 12) : 0x90000000u + ((pg - PG_MEM1) << 12);
                     fprintf(f, "%08X %d %016llx\n", a, skip_pg[pg], (unsigned long long)XXH3_64bits(G(a), 0x1000)); }
                     uint32_t lo[140], hi[140]; int nr = live_ranges(lo, hi, 138);       /* (and what RT_DET_HASH_LIVE leaves out) */
                     for (int i = 0; i < nr; i++) fprintf(f, "live %08X %08X\n", lo[i], hi[i]);
                     fclose(f); }
            if (getenv("RT_DET_DUMP_MEM")) {                /* (and all of MEM1 + MEM2, raw: .mem) */
                snprintf(p, sizeof p, pass > 1 ? "%s.mem%d" : "%s.mem", getenv("RT_DET_HASH"), pass); f = fopen(p, "wb");
                if (f) { fwrite(G(0x80000000u), 1, 24u << 20, f); fwrite(G(0x90000000u), 1, 64u << 20, f); fclose(f); } }
            const char *pk = getenv("RT_DET_PEEK");
            if (pk) { uint32_t a = (uint32_t)strtoul(pk, NULL, 16); snprintf(p, sizeof p, pass > 1 ? "%s.peek%d" : "%s.peek", getenv("RT_DET_HASH"), pass); f = fopen(p, "wb"); if (f) { fwrite(G(a), 1, 0x2000, f); fclose(f); } } } }
    if (hash_out) {
        static int every = -1; if (every < 0) { const char *e = getenv("RT_DET_HASH_EVERY"); every = e ? atoi(e) : 1; if (every < 1) every = 1; }
        if (g_vi_fields % (uint64_t)every == 0) {
            fprintf(hash_out, "%llu %llu %016llx\n", (unsigned long long)g_vi_fields, (unsigned long long)g_frames_presented,
                    (unsigned long long)det_state_hash());
            fflush(hash_out);
        }
    }
}
uint32_t det_keyboard(void) { return kb_latched; }
/* the real-time clock: a fixed date (2026-01-01 00:00, seconds since 2000) - the same everywhere */
uint32_t det_rtc_secs(void) { uint32_t t = session_on() ? session_rtc() : 0; return t ? t : 820454400u; }
